-- models/output.sql
{{ config(materialized='table') }}

SELECT 
    date,
    price_change_pct,

    -- Manually coded linear regression formula
    0.838115 + 
    (-0.109265 * sentiment_score) +
    ( -0.109265 * tweet_count) +
    (1.189873* lag_1_sentiment) +
    (-1.566642 * avg_3d_sentiment) +
    ( -0.109265 * weighted_impact) 
    

    AS predicted_price_change

FROM {{ ref('sentiment_features_final') }}
