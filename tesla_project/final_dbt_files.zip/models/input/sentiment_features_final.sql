-- models/sentiment_features_final.sql
{{ config(materialized='table') }}

SELECT 
    date,
    price_change_pct,
    sentiment_score,
    tweet_count,
    lag_1_sentiment,
    avg_3d_sentiment,
    avg_7d_close,
    weighted_impact,
    volume
FROM {{ ref('input') }}
WHERE price_change_pct IS NOT NULL
